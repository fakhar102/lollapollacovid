//
//  ViewController.h
//  BlunoTest
//
//  Created by Seifer on 13-12-1.
//  Copyright (c) 2013年 DFRobot. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VCMain.h"

@interface ViewController : UIViewController

@property (strong, nonatomic) VCMain* vcMain;

@end
